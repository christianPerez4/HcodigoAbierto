class LibrosController < ApplicationController
def index
	@libros = Libros.all
end
def show
	@libro = Libro.find(params[:id])
end
def new
	@libro = Libro.new
end
def create
	@libro = Libro.new(titulo: params[:libro][:titulo], autor: params[:libro][:autor], editorial: params[:libro][:editorial], num_pag: params[:libro][:num_pag])

	@libro.save
	redirect_to @libro
end
end